package com.loan.entity;

import java.util.Objects;

public class Loan {
	
	private int loanId;
	private Customer customer;
	private double principalAmount;
	private int interestRate;
    private int loanTerm;
    private String loanType;
    private String loanStatus;
    
    
	public Loan() {
		super();
	}



	public Loan(int loanId, Customer customer, double principalAmount, int interestRate, int loanTerm, String loanType,
			String loanStatus) {
		super();
		this.loanId = loanId;
		this.customer = customer;
		this.principalAmount = principalAmount;
		this.interestRate = interestRate;
		this.loanTerm = loanTerm;
		this.loanType = loanType;
		this.loanStatus = loanStatus;
	}



	public Loan(Customer customer, double principalAmount, int interestRate, int loanTerm, String loanType,
			String loanStatus) {
		super();
		this.customer = customer;
		this.principalAmount = principalAmount;
		this.interestRate = interestRate;
		this.loanTerm = loanTerm;
		this.loanType = loanType;
		this.loanStatus = loanStatus;
	}



	public int getLoanId() {
		return loanId;
	}



	public void setLoanId(int loanId) {
		this.loanId = loanId;
	}



	public Customer getCustomer() {
		return customer;
	}



	public void setCustomer(Customer customer) {
		this.customer = customer;
	}



	public double getPrincipalAmount() {
		return principalAmount;
	}



	public void setPrincipalAmount(float principalAmount) {
		this.principalAmount = principalAmount;
	}



	public int getInterestRate() {
		return interestRate;
	}



	public void setInterestRate(int interestRate) {
		this.interestRate = interestRate;
	}



	public int getLoanTerm() {
		return loanTerm;
	}



	public void setLoanTerm(int loanTerm) {
		this.loanTerm = loanTerm;
	}



	public String getLoanType() {
		return loanType;
	}



	public void setLoanType(String loanType) {
		this.loanType = loanType;
	}



	public String getLoanStatus() {
		return loanStatus;
	}



	public void setLoanStatus(String loanStatus) {
		this.loanStatus = loanStatus;
	}



	@Override
	public int hashCode() {
		return Objects.hash(customer, interestRate, loanId, loanStatus, loanTerm, loanType, principalAmount);
	}



	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Loan other = (Loan) obj;
		return Objects.equals(customer, other.customer) && interestRate == other.interestRate && loanId == other.loanId
				&& Objects.equals(loanStatus, other.loanStatus) && loanTerm == other.loanTerm
				&& Objects.equals(loanType, other.loanType)
				&& Double.doubleToLongBits(principalAmount) == Double.doubleToLongBits(other.principalAmount);
	}



	@Override
	public String toString() {
		return "Loan [loanId=" + loanId + ", customer=" + customer + ", principalAmount=" + principalAmount
				+ ", interestRate=" + interestRate + ", loanTerm=" + loanTerm + ", loanType=" + loanType
				+ ", loanStatus=" + loanStatus + "]";
	}
    
    
	
	

}
