package com.loan.service;

import java.util.List;

import com.loan.entity.Loan;

public interface ILoanRepositoryService {
	
	public void  applyLoan(Loan loan) ;
	public double calculateInterest(int loanId) ;
	public String loanStatus(int loadId) ;
	public double calculateEMI(int loanId) ;
	public  int loanRepayment(int loanId, double amount) ;
	public List<Loan> getAllLoan() ;
	public Loan getLoanById(int loanId);
	
	
}
