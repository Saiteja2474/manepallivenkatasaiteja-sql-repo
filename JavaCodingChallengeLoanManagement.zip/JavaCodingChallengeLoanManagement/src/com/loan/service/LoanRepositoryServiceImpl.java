package com.loan.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.loan.dao.ILoanDAO;
import com.loan.dao.LoanDAOImpl;
import com.loan.entity.Loan;
import com.loan.exception.InvalidLoanException;

public  class LoanRepositoryServiceImpl implements ILoanRepositoryService {
	
	ILoanDAO iLoanDAO;
	
	public LoanRepositoryServiceImpl() {
		iLoanDAO = new LoanDAOImpl();
		
	}

	@Override
	public void applyLoan(Loan loan) {
		
	}

	@Override
	public double calculateInterest(int loanId) {
	
		double res = 0;
		
		try {
			res = iLoanDAO.calculateInterest(loanId);
		}catch(SQLException s) {
			System.out.println("Either usrl,username,password incorrect");
		}catch(InvalidLoanException ile) {
			System.out.println("Loan Not Found");
		}catch(ClassNotFoundException cnfe) {
			System.out.println("JDBC not connected");
		}
		return res;
	}

	
	@Override
	public String loanStatus(int loanId) {
		
		String res = null;
		try {
			res = iLoanDAO.loanStatus(loanId);
		}catch(SQLException s) {
			System.out.println("Either usrl,username,password incorrect");
		}catch(InvalidLoanException ile) {
			System.out.println("Loan Not Found");
		}catch(ClassNotFoundException cnfe) {
			System.out.println("JDBC not connected");
		}
		return res;
	}

	@Override
	public double calculateEMI(int loanId) {
		
		double res = 0.0;
		try {
			res = iLoanDAO.calculateEMI(loanId);
		}catch(SQLException s) {
			System.out.println("Either usrl,username,password incorrect");
		}catch(InvalidLoanException ile) {
			System.out.println("Loan Not Found");
		}catch(ClassNotFoundException cnfe) {
			System.out.println("JDBC not connected");
		}
		return res;
		
	}

	@Override
	public int loanRepayment(int loanId, double amount)  {
		int noOfEmi = 0;
		try {
			noOfEmi = iLoanDAO.loanRepayment(loanId,amount);
		}catch(SQLException s) {
			System.out.println("Either usrl,username,password incorrect");
		}catch(InvalidLoanException ile) {
			String a = ile.getMessage();
			System.out.println(a);
		}catch(ClassNotFoundException cnfe) {
			System.out.println("JDBC not connected");
		}
		
		return noOfEmi;
	}

	@Override
	public List<Loan> getAllLoan() {
		
		List<Loan>loanList=new ArrayList<>();
		
		try {
			loanList = iLoanDAO.getAllLoan();
		}catch(SQLException s) {
			System.out.println("Either usrl,username,password incorrect");
		}catch(InvalidLoanException ile) {
			System.out.println("Loan Not Found");
		}catch(ClassNotFoundException cnfe) {
			System.out.println("JDBC not connected");
		}
		
		return loanList;
		
	}

	@Override
	public Loan getLoanById(int loanId) {
		Loan loan = null;
		try {
			loan = iLoanDAO.getLoanById(loanId);
		}catch(SQLException s) {
			System.out.println("Either usrl,username,password incorrect");
		}catch(InvalidLoanException ile) {
			System.out.println("Loan Not Found");
		}catch(ClassNotFoundException cnfe) {
			System.out.println("JDBC not connected");
		}
		
		return loan;
	}

}
