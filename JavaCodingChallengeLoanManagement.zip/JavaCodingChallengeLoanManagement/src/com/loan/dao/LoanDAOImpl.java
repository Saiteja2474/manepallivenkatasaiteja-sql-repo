package com.loan.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.loan.entity.Customer;
import com.loan.entity.Loan;
import com.loan.exception.InvalidLoanException;
import com.loan.util.DBUtil;

public class LoanDAOImpl implements ILoanDAO {

	
	Connection connection;
	
	@Override
	public void applyLoan(Loan loan) throws SQLException,ClassNotFoundException {
		
		connection = DBUtil.getConnection();
		
		
		connection.close();

	}

	@Override
	public double calculateInterest(int loanId) throws SQLException, InvalidLoanException,ClassNotFoundException {
		connection = DBUtil.getConnection();
		
		String query = "select * from loan where loanid=?";
		
		PreparedStatement stmt = connection.prepareStatement(query);
		
		stmt.setInt(1,loanId);
		
		Loan loan = null;
		
		ResultSet rs = stmt.executeQuery();
		
		
		double ans = 0;
		
		
		while(rs.next()) {
			
			int loanId1 = rs.getInt("loanid");
			int customerId = rs.getInt("customerid");
			double principalAmount = rs.getDouble("principalamount");
			int interestRate = rs.getInt("interestrate");
			int loanTerm = rs.getInt("loanterm");
			String loanType = rs.getString("loantype");
			String loanStatus = rs.getString("loanstatus");
			
			Customer customer = new Customer();
			customer.setCustomerId(customerId);
			
			loan = new Loan(loanId1,customer,principalAmount,interestRate,loanTerm,loanType,loanStatus);
			
		}

		if (loan == null) {
			throw new InvalidLoanException("Loan not found");
		}else {
			
			ans = (loan.getPrincipalAmount()*loan.getInterestRate()*loan.getLoanTerm())/12;
			
		}
		
		connection.close();
		
		return ans;
		
		
	}

	@Override
	public String loanStatus(int loanId) throws SQLException, ClassNotFoundException,InvalidLoanException {
		
		connection = DBUtil.getConnection();
		
		int creditScore =0;
		
		String query = "select creditscore from customer where customerid = ( select customerid from loan where loanid = ?)";
		
		PreparedStatement stmt = connection.prepareStatement(query);
		
		stmt.setInt(1,loanId);
		
		ResultSet rs = stmt.executeQuery();
		
		while(rs.next()) {
			creditScore = rs.getInt("creditscore");
		}
		
		connection.close();
		
		if(creditScore>650)return "Approved";
		else return "Pending";
		
		

	}

	@Override
	public double calculateEMI(int loanId) throws SQLException, ClassNotFoundException, InvalidLoanException {
		
		connection = DBUtil.getConnection();
		
        String query = "SELECT * FROM loan where loanid=?";
		
        PreparedStatement stmtloan = connection.prepareStatement(query);

		stmtloan.setInt(1, loanId);
		

		ResultSet rs = stmtloan.executeQuery();
		
		double emi = 0.0;
		
		while(rs.next()) {

			int loanId1 = rs.getInt("loanid");
			int customerId = rs.getInt("customerid");
			int principalAmount = rs.getInt("principalamount");
			double interestRate = rs.getInt("interestrate");
			
			double monthlyInterestRate = (interestRate)/12/100;
			int loanterm = rs.getInt("loanterm");
			
			String loantype = rs.getString("loantype");

			
			String loanstatus = rs.getString("loanstatus");
			emi = (principalAmount*monthlyInterestRate*Math.pow((1+monthlyInterestRate), loanterm))/Math.pow((1+monthlyInterestRate), loanterm-1);
			
			
		}
		
		if (emi == 0.0) {
			throw new InvalidLoanException("Loan not found");
		}
		
		connection.close();
		return emi;
	}



	@Override
	public int loanRepayment(int loanId, double amount) throws InvalidLoanException ,SQLException, ClassNotFoundException{
        double emi = calculateEMI(loanId);
        
        int noOfEmi = 0;
		
		if(emi>amount) {
			System.out.println("Amount is too less please increase the amount");
		}
		else {
			
			System.out.println(emi);
			noOfEmi = (int)(amount/emi);
		}
		
		if (noOfEmi ==0) {
			throw new InvalidLoanException("Loan Not Found");
		}
		
		return noOfEmi;
		
	}

	@Override
	public List<Loan> getAllLoan() throws SQLException, ClassNotFoundException, InvalidLoanException {
		
		List<Loan>loanList=new ArrayList<>();
		
		connection = DBUtil.getConnection();

		Loan loan = null;
        int customerid=0;
        int loanid=0;
        int principalamount=0;
        int interestrate=0;
        int loanTerm=0;
        String loanType=null;
        String loanStatus=null;
        
        Customer customer=null;
        String name=null;
        String email=null;
        String phoneno=null;
        String address=null;
        int creditScore=0;
		

		

		String query = "SELECT * FROM loan l join Customer c on l.customerid=c.customerid";
	
		PreparedStatement prepareStloan = connection.prepareStatement(query);

		ResultSet rsLoan = prepareStloan.executeQuery();

		while (rsLoan.next()) {// Till there are further records.
			loanid = rsLoan.getInt("loanid");
			customerid = rsLoan.getInt("customerid");
			principalamount = rsLoan.getInt("principalamount");
			interestrate = rsLoan.getInt("interestrate");
			loanTerm = rsLoan.getInt("loanterm");
			loanType = rsLoan.getString("loantype");
			loanStatus=rsLoan.getString("loanstatus");
			name=rsLoan.getString("Name");
			email=rsLoan.getString("email");
			phoneno=rsLoan.getString("Phoneno");
			address=rsLoan.getString("address");
			creditScore=rsLoan.getInt("creditScore");

			customer = new Customer(name,email,phoneno,address,creditScore);
			customer.setCustomerId(customerid);

			loan = new Loan(loanid,customer,principalamount,interestrate,loanTerm,loanType,loanStatus);
		
			loanList.add(loan);
		}
		connection.close();

		if (loanList.size() == 0) {
			throw new InvalidLoanException("No loan Found or invalid entry for fetching loan");
		}

		return loanList;
	}

	@Override
	public Loan getLoanById(int loanId) throws SQLException, ClassNotFoundException, InvalidLoanException {
		
			Loan loan = null;
	        int customerId=0;
	        Double principalAmount=0.0;
	        int interestRate=0;
	        int loanTerm=0;
	        
	        String loantype=null;
	        String loanStatus=null;
	        Customer customer=null;
	        String name=null;
	        String email=null;
	        String phoneno=null;
	        String address=null;
	        int creditScore=0;
			

			connection = DBUtil.getConnection();

			String query = "SELECT * FROM loan l JOIN Customer c "
					+ "USING(customerid) WHERE loanid = ?";
			
			PreparedStatement prepareStloan = connection.prepareStatement(query);

			prepareStloan.setInt(1, loanId);
			

			ResultSet rsLoan = prepareStloan.executeQuery();
			
			while (rsLoan.next()) {// Till there are further records.
				customerId = rsLoan.getInt("customerid");

				principalAmount = rsLoan.getDouble("principalamount");

				interestRate = rsLoan.getInt("interestrate");

				loanTerm = rsLoan.getInt("loanterm");

				loantype = rsLoan.getString("loantype");

				loanStatus=rsLoan.getString("loanstatus");

				name=rsLoan.getString("Name");
	
				email=rsLoan.getString("email");

				phoneno=rsLoan.getString("Phoneno");

				address=rsLoan.getString("address");

				creditScore=rsLoan.getInt("creditScore");

				customer = new Customer(name,email,phoneno,address,creditScore);
				
				customer.setCustomerId(customerId);

				loan = new Loan(loanId,customer,principalAmount,interestRate,loanTerm,loantype,loanStatus);
			
			}
			DBUtil.closeConnection();

			if (loan == null) {
				throw new InvalidLoanException("No loan Found or invalid entry for fetching loan");
			}
			
			return loan;
	}
}
